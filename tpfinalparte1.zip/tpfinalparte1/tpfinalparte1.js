/* TP FINAL PT 1 - campos salazar 94790/7 y fernandez yamila (...)
  SERIE ANIMADA ELEGIDA: Gravity Falls

  trabajo dividido en dos partes para una mejor organización: estructura, flujo de pantallas y botones; imágenes, sonido y texto. 
  
*/

let narrativa = [];
let estado = 0;
let ancho = 640;
let alto = 480;

let decisionesA = [];
let decisionesB = [];

function preload() {

  for (let i = 0; i <= 9; i++) {
    narrativa[i] = loadStrings("assets/texto" + i + ".txt");
  }


  decisionesA[2] = "Investigar la luz";
  decisionesB[2] = "Seguir durmiendo";


}

function setup() {
  createCanvas(ancho, alto);
  textAlign(CENTER, CENTER);
  textSize(16);
}

function draw() {
  background(20);

  if (estado === 0) {
    pantalla(0, "COMENZAR", "CRÉDITOS");
  } 
  else if (estado === 9) {
    pantFinal();
  } 
  else if (estado === 10) {
    pantCreditos();
  } 
  else if (decisionesA[estado] && decisionesB[estado]) {
    pantDecisiones(decisionesA[estado], decisionesB[estado]);
  } 
  else {
    pantalla(estado, "SIGUIENTE");
  }
}

function mousePressed() {

  if (estado === 0 && limiteBoton(340, 300, 140, 50)) estado = 1;
  else if (estado === 0 && limiteBoton(160, 300, 140, 50)) estado = 10;

  else if (estado === 10 && limiteBoton(250, 420, 140, 40)) estado = 0;


  else if (limiteBoton(540, 440, 80, 30)) {
    estado++;
    if (estado > 9) estado = 9;
  }


  if (estado === 2 && limiteBoton(100, 420, 120, 40)) estado = 3; 
  else if (estado === 2 && limiteBoton(400, 420, 120, 40)) estado = 4;
}

function pantalla(num, textoBtnA, textoBtnB) {
  pantTexto(num);
  if (textoBtnB) {
    boton(160, 300, 140, 50, textoBtnB);
    boton(340, 300, 140, 50, textoBtnA);
  } else {
    boton(540, 440, 80, 30, textoBtnA);
  }
}

function pantDecisiones(opcionIzq, opcionDer) {
  pantTexto(estado);
  boton(100, 420, 120, 40, opcionIzq);
  boton(400, 420, 120, 40, opcionDer);
}

function pantFinal() {
  background(0);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(18);
  text("El bosque se quiebra y siento su risa dentro de mí.\n(FINAL MALO)", width / 2, height / 2);
  textSize(14);
  text("SIGUIENTE >", width / 2, height / 2 + 60);
  textAlign(LEFT);
}

function pantCreditos() {
  background(10);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(18);
  text("Créditos\nAventura gráfica - Proyecto conjunto", width / 2, height / 2);
  boton(250, 420, 140, 40, "VOLVER");
  textAlign(LEFT);
}



function limiteBoton(x, y, w, h) {
  return mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h;
}

function boton(x, y, w, h, texto) {
  let hover = limiteBoton(x, y, w, h);
  fill(hover ? 80 : 40);
  stroke(hover ? 255 : 200);
  strokeWeight(1);
  rect(x, y, w, h, 10);
  noStroke();
  fill(255);
  textAlign(CENTER, CENTER);
  text(texto, x + w / 2, y + h / 2);
  textAlign(LEFT);
}

function pantTexto(num) {
  fill(0, 180);
  noStroke();
  rect(20, 100, 600, 100, 12); 
  fill(255);
  textSize(16);
  text(narrativa[num], 40, 110, 560, 80);
}
